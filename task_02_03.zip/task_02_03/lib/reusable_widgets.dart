import 'package:flutter/material.dart';

ElevatedButton customElevatedButton(String text, Function onPress) {
  return ElevatedButton(
    style: const ButtonStyle(
      backgroundColor: MaterialStatePropertyAll(
        Colors.white,
      ),
    ),
    onPressed: () {
      onPress();
    },
    child: Text(
      text,
    ),
  );
}

AppBar customAppBar(String label) {
  return AppBar(
    backgroundColor: Colors.blue,
    title: Text(
      label,
      style: const TextStyle(fontSize: 20, color: Colors.white),
    ),
    centerTitle: true,
  );
}
