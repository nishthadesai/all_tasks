import 'package:flutter/material.dart';
import 'package:task_02_03/reusable_widgets.dart';
import 'package:task_02_03/task_one.dart';
import 'package:task_02_03/task_two.dart';

class TaskList extends StatelessWidget {
  const TaskList({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            customElevatedButton("TaskOne", () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => const TaskOne(),
                ),
              );
            }),
            customElevatedButton("TaskTwo", () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => const LoginPage(),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
