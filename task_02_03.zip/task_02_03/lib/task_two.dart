import 'package:flutter/material.dart';
import 'package:task_02_03/registration.dart';
import 'package:task_02_03/reusable_widgets.dart';

final _formKey = GlobalKey<FormState>();

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _nameController = TextEditingController();
  final _passController = TextEditingController();

  void _showDialog() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            shadowColor: Colors.black,
            backgroundColor: const Color.fromRGBO(240, 228, 242, 1),
            content: const Text("Do yo want to Login??"),
            actions: [
              MaterialButton(
                onPressed: () {
                  _formKey.currentState!.reset();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Data Saved Successfully'),
                    ),
                  );
                  Navigator.pop(context);
                },
                child: const Text("Yes"),
              ),
              MaterialButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text("Cancel"),
              ),
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: customAppBar("Login"),
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              autovalidateMode: AutovalidateMode.onUserInteraction,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 50, left: 15, right: 15),
                    child: Text(
                      "Welcome Back",
                      style: TextStyle(
                        fontSize: 50,
                      ),
                    ),
                  ),
                  const Text(
                    "Enter your Credential to Login",
                    style: TextStyle(
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(
                    height: 40,
                  ),
                  TextFormField(
                    controller: _nameController,
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      fillColor: const Color.fromRGBO(240, 228, 242, 1),
                      filled: true,
                      hintText: "UserName",
                      labelStyle: const TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                      ),
                      prefixIcon: const Icon(Icons.person),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    validator: (name) {
                      if (name == null || name.isEmpty) {
                        return "Please fill this";
                      } else if (name.length < 3) {
                        return "Please enter name with at least 3 character";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  TextFormField(
                    controller: _passController,
                    keyboardType: TextInputType.visiblePassword,
                    obscureText: true,
                    decoration: InputDecoration(
                      fillColor: const Color.fromRGBO(240, 228, 242, 1),
                      filled: true,
                      hintText: "Password",
                      labelStyle: const TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                      ),
                      prefixIcon: const Icon(Icons.password),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    validator: (pass) {
                      if (pass == null || pass.isEmpty) {
                        return "Please fill this";
                      } else if (pass.length < 6) {
                        return "Please enter password with at least 6 character";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  ElevatedButton(
                    style: const ButtonStyle(
                      shape: MaterialStatePropertyAll(
                        RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(30))),
                      ),
                      fixedSize: MaterialStatePropertyAll(
                        Size(400, 50),
                      ),
                      backgroundColor: MaterialStatePropertyAll(
                        Colors.purple,
                      ),
                    ),
                    onPressed: () {
                      if (_formKey.currentState!.validate() == true) {
                        _showDialog();
                      } else {
                        return;
                      }
                    },
                    child: const Text(
                      "Login",
                      style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                  ),
                  const SizedBox(
                    height: 90,
                  ),
                  const Text(
                    "Forget Password?",
                    style: TextStyle(color: Colors.purple),
                  ),
                  const SizedBox(
                    height: 110,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        "Don't have an account? ",
                        style: TextStyle(color: Colors.black),
                      ),
                      TextButton(
                          onPressed: () => Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => const RagisterPage(),
                                ),
                              ),
                          child: const Text(
                            "SignUp",
                            style: TextStyle(color: Colors.purple),
                          )),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
