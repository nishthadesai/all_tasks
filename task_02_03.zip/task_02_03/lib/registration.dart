import 'package:flutter/material.dart';
import 'package:task_02_03/task_two.dart';

final _formKey = GlobalKey<FormState>();

class RagisterPage extends StatefulWidget {
  const RagisterPage({super.key});

  @override
  State<RagisterPage> createState() => _RagisterPageState();
}

class _RagisterPageState extends State<RagisterPage> {
  final _nameController = TextEditingController();
  final _passController = TextEditingController();
  final _emailController = TextEditingController();
  final _cPassController = TextEditingController();

  String? validateEmail(String? email) {
    RegExp emailRex = RegExp(
        r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
    final isEmailValid = emailRex.hasMatch(email ?? '');
    if (!isEmailValid) {
      return "Please enter valid email";
    } else {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 50, left: 15, right: 15),
                    child: Text(
                      "Sign up",
                      style: TextStyle(
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    "Create your Account",
                    style: TextStyle(
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  TextFormField(
                    controller: _nameController,
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      fillColor: const Color.fromRGBO(240, 228, 242, 1),
                      filled: true,
                      hintText: "UserName",
                      labelStyle: const TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                      ),
                      prefixIcon: const Icon(Icons.person),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    validator: (name) {
                      if (name == null || name.isEmpty) {
                        return "Please fill this";
                      } else if (name.length < 3) {
                        return "Please enter name with at least 3 character";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  TextFormField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      fillColor: const Color.fromRGBO(240, 228, 242, 1),
                      filled: true,
                      hintText: "Email",
                      labelStyle: const TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                      ),
                      prefixIcon: const Icon(Icons.email),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    validator: validateEmail,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  TextFormField(
                    controller: _passController,
                    keyboardType: TextInputType.visiblePassword,
                    obscureText: true,
                    decoration: InputDecoration(
                      fillColor: const Color.fromRGBO(240, 228, 242, 1),
                      filled: true,
                      hintText: "Password",
                      labelStyle: const TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                      ),
                      prefixIcon: const Icon(Icons.password),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    validator: (pass) {
                      if (pass == null || pass.isEmpty) {
                        return "Please fill this";
                      } else if (pass.length < 6) {
                        return "Please enter password with at least 6 character";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  TextFormField(
                    controller: _cPassController,
                    keyboardType: TextInputType.visiblePassword,
                    obscureText: true,
                    decoration: InputDecoration(
                      fillColor: const Color.fromRGBO(240, 228, 242, 1),
                      filled: true,
                      hintText: "Confirm Password",
                      labelStyle: const TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                      ),
                      prefixIcon: const Icon(Icons.password),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    validator: (cPass) {
                      if (cPass == null || cPass.isEmpty) {
                        return "Please fill this";
                      } else if (_passController.text !=
                          _cPassController.text) {
                        return "Password and Confirm password are same";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  ElevatedButton(
                    style: const ButtonStyle(
                      shape: MaterialStatePropertyAll(
                        RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(30))),
                      ),
                      fixedSize: MaterialStatePropertyAll(
                        Size(400, 50),
                      ),
                      backgroundColor: MaterialStatePropertyAll(
                        Colors.purple,
                      ),
                    ),
                    onPressed: () {
                      if (_formKey.currentState!.validate() == true) {
                        _formKey.currentState!.reset();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Register Successfully, Now Login'),
                          ),
                        );
                      } else {
                        return;
                      }
                    },
                    child: const Text(
                      "Sign up",
                      style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                  ),
                  const SizedBox(
                    height: 40,
                  ),
                  const Text("or"),
                  const SizedBox(
                    height: 30,
                  ),
                  customElevatedButton1(),
                  const SizedBox(
                    height: 30,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        "Already have an Account? ",
                        style: TextStyle(color: Colors.black),
                      ),
                      TextButton(
                          onPressed: () => Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => const LoginPage(),
                                ),
                              ),
                          child: const Text(
                            "Login",
                            style: TextStyle(color: Colors.purple),
                          )),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

ElevatedButton customElevatedButton1() {
  return ElevatedButton(
    style: const ButtonStyle(
      shape: MaterialStatePropertyAll(
        RoundedRectangleBorder(
          side: BorderSide(color: Colors.purple, width: 1),
          borderRadius: BorderRadius.all(
            Radius.circular(30),
          ),
        ),
      ),
      fixedSize: MaterialStatePropertyAll(
        Size(400, 50),
      ),
    ),
    onPressed: () {},
    child: const Text(
      "Sign in With Google",
      style: TextStyle(color: Colors.purple, fontSize: 20),
    ),
  );
}
