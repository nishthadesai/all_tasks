package com.example.task_01_04

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
