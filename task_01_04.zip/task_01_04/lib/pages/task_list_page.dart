import 'package:flutter/material.dart';

import 'my_router_page.dart';

class TaskListDetails extends StatefulWidget {
  const TaskListDetails({super.key});

  @override
  State<TaskListDetails> createState() => _TaskListDetailsState();
}

class _TaskListDetailsState extends State<TaskListDetails> {
  List data = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        centerTitle: true,
        title: const Text("Task Lists"),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.lightBlueAccent,
        child: const Center(
          child: Icon(
            Icons.add,
            color: Colors.black,
          ),
        ),
        onPressed: () {
          _navigate(context);
        },
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          data.isNotEmpty
              ? Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: ListView.builder(
                      itemCount: data.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                            title: Text('Task$index: ${data[index]}'));
                      },
                    ),
                  ),
                )
              : const Center(
                  child: Text(
                    "No Tasks Yet",
                    style: TextStyle(fontSize: 25),
                  ),
                ),
        ],
      ),
    );
  }

  void _navigate(BuildContext context) async {
    final task = await Navigator.pushNamed(context, MyRouter.addTasks);
    setState(() {
      data.add(task);
    });
  }
}
