import 'package:flutter/material.dart';
import 'package:task_01_04/pages/splash_screen.dart';
import 'package:task_01_04/pages/task_list_page.dart';

import 'add_task_list.dart';

class MyRouter {
  static const String root = "/";
  static const String taskList = "/task_list_page";
  static const String addTasks = "/add_task_list";

  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    Widget page = const SplashScreenPage();
    switch (settings.name) {
      case root:
        page = const SplashScreenPage();
        break;
      case taskList:
        page = const TaskListDetails();
        break;
      case addTasks:
        page = const AddTasks();
        break;
    }
    return MaterialPageRoute(
      builder: (context) => page,
      settings: settings,
    );
  }

  static Route onUnknownRoute(RouteSettings settings) {
    return MaterialPageRoute(
      settings: settings,
      builder: (context) => const Scaffold(
        body: Center(
          child: Text("Route Not Found !!"),
        ),
      ),
    );
  }
}
