import 'package:flutter/material.dart';
import 'package:task_01_03/reusable_widgets.dart';

class TaskThreeOne extends StatelessWidget {
  const TaskThreeOne({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SafeArea(
        child: Scaffold(
          appBar: customAppBar("Task Three"),
          body: Padding(
            padding: const EdgeInsets.only(top: 30, left: 50),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                customTextField1(),
                const SizedBox(
                  height: 20,
                ),
                customTextField2(),
                const SizedBox(
                  height: 20,
                ),
                button(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

SizedBox customTextField1() {
  return SizedBox(
    height: 80,
    width: 300,
    child: TextField(
        decoration: InputDecoration(
            hintText: "Username",
            fillColor: Colors.blue.shade50,
            filled: true,
            prefixIcon: const Icon(
              Icons.email,
              color: Colors.blue,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(25),
              borderSide: BorderSide.none,
            )),
        showCursor: false,
        keyboardType: TextInputType.name),
  );
}

SizedBox customTextField2() {
  return SizedBox(
    height: 80,
    width: 300,
    child: TextField(
        decoration: InputDecoration(
            hintText: "Password",
            fillColor: Colors.blue.shade50,
            filled: true,
            suffixIcon: const Icon(
              Icons.visibility_off,
            ),
            prefixIcon: const Icon(
              Icons.lock,
              color: Colors.blue,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(25),
              borderSide: BorderSide.none,
            )),
        showCursor: false,
        keyboardType: TextInputType.name),
  );
}

ElevatedButton button() {
  return ElevatedButton(
      style: const ButtonStyle(
        backgroundColor: MaterialStatePropertyAll(
          Colors.blue,
        ),
        fixedSize: MaterialStatePropertyAll(
          Size(300, 70),
        ),
      ),
      onPressed: () {},
      child: const Center(
        child: Text(
          "Login",
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
          ),
        ),
      ));
}
