import 'package:flutter/material.dart';

class TaskOne extends StatelessWidget {
  const TaskOne({super.key});

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double safeAreaTop = MediaQuery.of(context).padding.top;
    double safeAreaBottom = MediaQuery.of(context).padding.bottom;
    double safeAreaTopBottom = MediaQuery.of(context).padding.vertical;
    double appBarHeight = MediaQuery.of(context).padding.top + kToolbarHeight;
    double topPadding = MediaQuery.of(context).padding.top;
    double bottomPadding = MediaQuery.of(context).padding.bottom;
    double usableScreen = MediaQuery.of(context).size.height -
        (MediaQuery.of(context).padding.top + kToolbarHeight) -
        (MediaQuery.of(context).padding.top);

    return SafeArea(
      top: false,
      bottom: false,
      child: Scaffold(
        appBar: buildAppbar(),
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: [
              Text(
                "Height of Screen: $screenHeight",
                style: const TextStyle(
                  fontSize: 20,
                  color: Colors.black,
                ),
              ),
              Text(
                "Safe Area Top: $safeAreaTop",
                style: const TextStyle(
                  fontSize: 20,
                  color: Colors.black,
                ),
              ),
              Text(
                "Safe Area Bottom: $safeAreaBottom",
                style: const TextStyle(
                  fontSize: 20,
                  color: Colors.black,
                ),
              ),
              Text(
                "Safe Area Top & Bottom: $safeAreaTopBottom",
                style: const TextStyle(
                  fontSize: 20,
                  color: Colors.black,
                ),
              ),
              Text(
                "AppBar Height: $appBarHeight",
                style: const TextStyle(
                  fontSize: 20,
                  color: Colors.black,
                ),
              ),
              Text(
                "Top Padding: $topPadding",
                style: const TextStyle(
                  fontSize: 20,
                  color: Colors.black,
                ),
              ),
              Text(
                "Bottom Padding: $bottomPadding",
                style: const TextStyle(
                  fontSize: 20,
                  color: Colors.black,
                ),
              ),
              Text(
                "Usable Screen height: $usableScreen",
                style: const TextStyle(
                  fontSize: 20,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

PreferredSizeWidget buildAppbar() {
  return AppBar(
    backgroundColor: Colors.blue,
    title: const Text("Task One"),
  );
}
