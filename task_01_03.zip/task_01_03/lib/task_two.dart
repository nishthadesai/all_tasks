import 'package:flutter/material.dart';

class TaskTwo extends StatefulWidget {
  const TaskTwo({super.key});

  @override
  State<TaskTwo> createState() => _TaskTwoState();
}

class _TaskTwoState extends State<TaskTwo> {
  bool isVisible = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Task Two"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(top: 150, bottom: 50),
                  child: Visibility(
                    //for maintain button content
                    maintainSize: true,
                    maintainAnimation: true,
                    maintainState: true,
                    visible: isVisible,
                    child: const Image(
                      image: AssetImage("assets/images/flutter.png"),
                    ),
                  ),
                ),
              ),
              ElevatedButton(
                style: ButtonStyle(
                  fixedSize: const MaterialStatePropertyAll(
                    Size(250, 50),
                  ),
                  backgroundColor: MaterialStatePropertyAll(
                    isVisible == false ? Colors.grey : Colors.blue,
                  ),
                ),
                onPressed: () {
                  setState(() {
                    isVisible = true;
                  });
                },
                child: const Text(
                  "Show Logo",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              ElevatedButton(
                style: const ButtonStyle(
                  fixedSize: MaterialStatePropertyAll(
                    Size(250, 50),
                  ),
                  backgroundColor: MaterialStatePropertyAll(
                    Colors.blue,
                  ),
                ),
                onPressed: () {
                  setState(() {
                    isVisible = false;
                  });
                },
                child: const Text(
                  "Hide Logo",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
